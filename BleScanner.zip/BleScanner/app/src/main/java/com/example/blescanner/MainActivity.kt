package com.example.blescanner

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var scanButton: Button
    private lateinit var statusText: TextView
    private lateinit var deviceListView: ListView

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var bleScanner: BluetoothLeScanner? = null
    private var isScanning = false
    private val scanHandler = Handler(Looper.getMainLooper())
    private val scanDurationMs = 12_000L

    // address -> строка для отображения (чтобы не дублировать устройства)
    private val foundDevices = LinkedHashMap<String, String>()
    private lateinit var listAdapter: ArrayAdapter<String>

    // Разрешения, нужные в зависимости от версии Android
    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

    private val permissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) { results ->
            if (results.values.all { it }) {
                startScan()
            } else {
                statusText.text = "Нужны разрешения на Bluetooth, чтобы искать устройства"
            }
        }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val address = device.address

            val name = try {
                device.name
            } catch (e: SecurityException) {
                null
            } ?: result.scanRecord?.deviceName ?: "Без имени"

            val display = "$name\n$address   RSSI: ${result.rssi} dBm"
            val isNew = !foundDevices.containsKey(address)
            foundDevices[address] = display

            if (isNew) {
                runOnUiThread {
                    refreshList()
                    statusText.text = "Найдено устройств: ${foundDevices.size}"
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread {
                statusText.text = "Ошибка сканирования: код $errorCode"
                setScanningState(false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scanButton = findViewById(R.id.scanButton)
        statusText = findViewById(R.id.statusText)
        deviceListView = findViewById(R.id.deviceListView)

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        deviceListView.adapter = listAdapter

        val bluetoothManager = getSystemService(BluetoothManager::class.java)
        bluetoothAdapter = bluetoothManager.adapter

        scanButton.setOnClickListener {
            if (isScanning) {
                stopScan()
            } else {
                checkPermissionsAndScan()
            }
        }
    }

    private fun checkPermissionsAndScan() {
        if (!::bluetoothAdapter.isInitialized || bluetoothAdapter == null) {
            Toast.makeText(this, "На этом устройстве нет Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            Toast.makeText(this, "Включите Bluetooth и попробуйте снова", Toast.LENGTH_SHORT).show()
            return
        }

        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            startScan()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startScan() {
        bleScanner = bluetoothAdapter.bluetoothLeScanner
        if (bleScanner == null) {
            statusText.text = "Не удалось получить доступ к Bluetooth-сканеру"
            return
        }

        foundDevices.clear()
        refreshList()
        setScanningState(true)
        statusText.text = "Поиск устройств..."

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        try {
            bleScanner?.startScan(null, settings, scanCallback)
        } catch (e: SecurityException) {
            statusText.text = "Нет разрешения на сканирование"
            setScanningState(false)
            return
        }

        // Автоматически останавливаем сканирование через заданное время,
        // чтобы не разряжать батарею
        scanHandler.postDelayed({ stopScan() }, scanDurationMs)
    }

    private fun stopScan() {
        try {
            bleScanner?.stopScan(scanCallback)
        } catch (e: SecurityException) {
            // разрешение уже могло быть отозвано — просто игнорируем
        }
        scanHandler.removeCallbacksAndMessages(null)
        setScanningState(false)
        statusText.text = "Поиск остановлен. Найдено устройств: ${foundDevices.size}"
    }

    private fun setScanningState(scanning: Boolean) {
        isScanning = scanning
        scanButton.text = if (scanning) "Остановить поиск" else "Начать поиск"
    }

    private fun refreshList() {
        listAdapter.clear()
        listAdapter.addAll(foundDevices.values)
        listAdapter.notifyDataSetChanged()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isScanning) {
            try {
                bleScanner?.stopScan(scanCallback)
            } catch (e: SecurityException) {
                // ignore
            }
        }
    }
}
